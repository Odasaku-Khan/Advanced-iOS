//
//  lab1v2Tests.swift
//  lab1v2Tests
//
//  Created by Ablaikhan Nusypakhin on 3/6/25.
//

import Testing
@testable import lab1v2

struct lab1v2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
