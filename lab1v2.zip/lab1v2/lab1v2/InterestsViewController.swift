import UIKit

class InterestsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!  // Ensure this is connected in Storyboard

    let interests = ["Coding", "Reading", "Gaming", "Photography"]

    override func viewDidLoad() {
        super.viewDidLoad()

        // Debugging check
        if tableView == nil {
            print("❌ Error: tableView is nil")
        } else {
            print("✅ tableView is connected properly")
        }

        tableView.delegate = self
        tableView.dataSource = self
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return interests.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = interests[indexPath.row]
        return cell
    }

}
